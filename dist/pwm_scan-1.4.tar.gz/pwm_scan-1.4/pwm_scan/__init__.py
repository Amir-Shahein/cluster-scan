"""
Version: 1.4

Author: Yu-Cheng Lin

Changes:
    Move to Python 3. Change Python 2 syntax like print and xrange() to Python 3 compatible syntax.
"""

__version__ = 1.4

from .main import *
