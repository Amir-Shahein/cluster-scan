"""
Position-weight-matrix (PWM) scan through genomic sequence
"""

__version__ = '2.0.0'

from .main import *
